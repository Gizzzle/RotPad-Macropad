/* Copyright 2021 Alexander Gutsch <alex.d.gutsch@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include QMK_KEYBOARD_H
#include <stdio.h>

void keyboard_post_init_user(void) {
  // Customise these values to desired behaviour
  debug_enable=true;
  debug_matrix=true;
  //debug_keyboard=true;
  //debug_mouse=true;
}

#define _NUMPAD 0
#define _FUNCTION 1
#define _RGB 2

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [_NUMPAD] = LAYOUT(
    KC_MUTE, KC_PSLS, KC_PAST, KC_MPLY,
    KC_P7, KC_P8, KC_P9, KC_PMNS, 
    KC_P4, KC_P5, KC_P6, KC_PPLS,
	KC_P1, KC_P2, KC_P3, KC_PENT,	     
	KC_P0, KC_PDOT      
    ),
	[_FUNCTION] = LAYOUT(
    KC_F12, KC_TRNS, KC_TRNS, RESET,
    KC_F9, KC_F10, KC_F11, KC_TRNS, 
    KC_F6, KC_F7, KC_F8, KC_TRNS,
	KC_F3, KC_4, KC_P5, KC_TRNS,	     
	KC_F1, KC_F2      
    ),
	[_RGB] = LAYOUT(
    RGB_M_SW, RGB_M_SN, RGB_M_X, RESET,
    RGB_VAD, RGB_VAI, RGB_M_R, RGB_M_K, 
    RGB_HUD, RGB_HUI, RGB_SAD, RGB_SAI,
	RGB_RMOD, RGB_MOD, RGB_M_P, RGB_M_B,	     
	RGB_TOG, RGB_M_G      
    ),
};


uint8_t selected_layer = 0;
void encoder_update_user(uint8_t index, bool clockwise) {
    if (index == 0) {
		if (!clockwise) {
			tap_code(KC_VOLU);
		} else {
			tap_code(KC_VOLD);
		}
	}
	
    else if (index == 1) {
		if (!clockwise && selected_layer  < 10) {
			selected_layer ++;
		} else if (clockwise && selected_layer  > 0){
			selected_layer --;
		}
			layer_clear();
			layer_on(selected_layer);
           }
          }



bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  // If console is enabled, it will print the matrix position and status of each key pressed
#ifdef CONSOLE_ENABLE
    uprintf("KL: kc: 0x%04X, col: %u, row: %u, pressed: %b, time: %u, interrupt: %b, count: %u\n", keycode, record->event.key.col, record->event.key.row, record->event.pressed, record->event.time, record->tap.interrupted, record->tap.count);
#endif 
  return true;
}

#ifdef OLED_DRIVER_ENABLE
extern rgblight_config_t rgblight_config;

oled_rotation_t oled_init_user(oled_rotation_t rotation) {
    return OLED_ROTATION_90;  // flips the display 270 degrees
}

void oled_task_user(void) {
  // Host Keyboard Layer Status
  oled_write_P(PSTR("Layer"), false);
  switch (biton32(layer_state)) {
    case _NUMPAD:
      oled_write_ln_P(PSTR(" NUM"), false);
      break;
    case _FUNCTION:
      oled_write_ln_P(PSTR(" FUN"), false);
      break;
    case _RGB:
      oled_write_ln_P(PSTR(" RGB"), false);
      break;
    default:
      // Or use the write_ln shortcut over adding '\n' to the end of your string
      oled_write_ln_P(PSTR(" UND"), false);
  }

  // Host Keyboard LED Status
  uint8_t led_usb_state = host_keyboard_leds();
  oled_write_P(PSTR("-----"), false);
  oled_write_P(PSTR("Stats"), false);
  oled_write_P(led_usb_state & (1<<USB_LED_NUM_LOCK) ? PSTR("num:*") : PSTR("num:."), false);
  oled_write_P(led_usb_state & (1<<USB_LED_CAPS_LOCK) ? PSTR("cap:*") : PSTR("cap:."), false);
  oled_write_P(led_usb_state & (1<<USB_LED_SCROLL_LOCK) ? PSTR("scr:*") : PSTR("scr:."), false);

  // Host Keyboard RGB backlight status
  oled_write_P(PSTR("-----"), false);
  oled_write_P(PSTR("Light"), false);

  static char led_buf[30];
  snprintf(led_buf, sizeof(led_buf) - 1, "RGB:%cM: %2d\nh: %2ds: %2dv: %2d\n",
      rgblight_config.enable ? '*' : '.', (uint8_t)rgblight_config.mode,
      (uint8_t)(rgblight_config.hue / RGBLIGHT_HUE_STEP),
      (uint8_t)(rgblight_config.sat / RGBLIGHT_SAT_STEP),
      (uint8_t)(rgblight_config.val / RGBLIGHT_VAL_STEP));
  oled_write(led_buf, false);
}
#endif